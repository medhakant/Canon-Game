g++ -O3 -O2 -O1 -o BT7274 canonPlayer.cpp
